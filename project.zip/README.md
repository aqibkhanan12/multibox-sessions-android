# MultiBox Sessions – Android

Use several accounts on the same website at the same time. Every session runs in its own
Android WebView **profile** (`androidx.webkit` `ProfileStore`), so cookies, localStorage,
IndexedDB, cache and service workers are fully separate per session.

## Features
- Unlimited sessions, each with its own name, color and start page
- Temporary sessions (deleted with all data when closed)
- Each session opens as its own window in Android "Recents"
- Home-screen shortcut for any session
- "Log out everywhere" (clear one session's data)
- Open the current page in another session, share links into the app
- File uploads, downloads (with the session's login), full-screen video, desktop mode
- Optional PIN lock (auto-locks after 5 minutes in the background)
- English + Urdu, light/dark mode, no ads, no tracking, no server

Requires a phone whose **Android System WebView** supports multiple profiles
(kept up to date through the Play Store). Older WebView → the app asks to update it.

## Build
GitHub Actions builds everything on every push (`.github/workflows/build.yml`):
- `MultiBox-Sessions-debug-N.apk` – install directly on a phone
- `MultiBox-Sessions-N.apk` – signed release APK (needs the signing secrets)
- `MultiBox-Sessions-PlayStore-N.aab` – upload this to Google Play

Signing secrets (repo → Settings → Secrets and variables → Actions):
`SIGNING_KEYSTORE_BASE64`, `SIGNING_STORE_PASSWORD`, `SIGNING_KEY_ALIAS`, `SIGNING_KEY_PASSWORD`.

The version code is the GitHub run number, so every build can be uploaded to Play as a new version.

Local build (Android Studio): open this folder and choose **Build → Build APK(s)**.

## Config
- `MainActivity.PRIVACY_URL` – your privacy-policy page (shown in About).
- Package name: `com.multiboxsessions.app` (change `applicationId` in `app/build.gradle.kts`
  **before** the first Play upload if you want a different one; it can't change later).
