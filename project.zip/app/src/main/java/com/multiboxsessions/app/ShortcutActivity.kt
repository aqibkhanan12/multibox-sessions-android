package com.multiboxsessions.app

import android.app.Activity
import android.os.Bundle
import android.widget.Toast

/** Started by a home-screen shortcut: opens that one session directly. */
class ShortcutActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra(BrowserActivity.EXTRA_ID)
        if (id != null && SessionStore.get(this, id) != null && Profiles.supported()) {
            startActivity(BrowserActivity.newIntent(this, id))
        } else {
            Toast.makeText(this, R.string.session_missing, Toast.LENGTH_LONG).show()
        }
        finish()
    }

    companion object {
        const val ACTION = "com.multiboxsessions.app.OPEN_SESSION"
    }
}
