package com.multiboxsessions.app

import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/** PIN screen shown over the app when the lock is on. */
class LockActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lock)
        val root = findViewById<View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsetsCompat.CONSUMED
        }

        val pin = findViewById<EditText>(R.id.pin)
        val error = findViewById<TextView>(R.id.error)
        val tryUnlock = {
            if (Lock.unlockWith(this, pin.text.toString())) {
                finish()
            } else {
                error.visibility = View.VISIBLE
                pin.text.clear()
            }
        }
        findViewById<View>(R.id.unlockBtn).setOnClickListener { tryUnlock() }
        pin.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_GO) { tryUnlock(); true } else false
        }

        // Back must not skip the lock: send the app to the background instead.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                moveTaskToBack(true)
            }
        })
    }

    override fun onResume() {
        super.onResume()
        if (!Lock.needsUnlock(this)) finish()
    }
}
