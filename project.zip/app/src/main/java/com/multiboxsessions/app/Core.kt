package com.multiboxsessions.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.Profile
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.UUID

/** Session colors (same palette as the Chrome extension / Chrome tab groups). */
val SESSION_COLORS = intArrayOf(
    0xFF1A73E8.toInt(), 0xFFD93025.toInt(), 0xFF188038.toInt(), 0xFF9334E6.toInt(), 0xFFE8710A.toInt(),
    0xFF007B83.toInt(), 0xFFD01884.toInt(), 0xFFF9AB00.toInt(), 0xFF5F6368.toInt()
)

data class Session(
    val id: String,
    var name: String,
    var color: Int,
    var temp: Boolean,
    var homeUrl: String,
    var lastUrl: String,
    val created: Long,
    var lastUsed: Long,
    var desktop: Boolean
) {
    /** Name of the WebView profile that holds this session's cookies and storage. */
    val profileName: String get() = "mb_$id"

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("color", color).put("temp", temp)
        .put("homeUrl", homeUrl).put("lastUrl", lastUrl).put("created", created)
        .put("lastUsed", lastUsed).put("desktop", desktop)

    companion object {
        fun fromJson(o: JSONObject) = Session(
            id = o.getString("id"),
            name = o.optString("name", "Session"),
            color = o.optInt("color", SESSION_COLORS[0]),
            temp = o.optBoolean("temp", false),
            homeUrl = o.optString("homeUrl", ""),
            lastUrl = o.optString("lastUrl", ""),
            created = o.optLong("created", 0L),
            lastUsed = o.optLong("lastUsed", 0L),
            desktop = o.optBoolean("desktop", false)
        )
    }
}

object SessionStore {
    private const val PREFS = "multibox"
    private const val KEY = "sessions"

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun all(c: Context): MutableList<Session> {
        val out = mutableListOf<Session>()
        try {
            val arr = JSONArray(prefs(c).getString(KEY, "[]"))
            for (i in 0 until arr.length()) out.add(Session.fromJson(arr.getJSONObject(i)))
        } catch (e: Exception) {
            // corrupted data: start empty rather than crash
        }
        return out
    }

    private fun saveAll(c: Context, list: List<Session>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs(c).edit().putString(KEY, arr.toString()).apply()
    }

    fun get(c: Context, id: String): Session? = all(c).firstOrNull { it.id == id }

    fun upsert(c: Context, s: Session) {
        val list = all(c)
        val i = list.indexOfFirst { it.id == s.id }
        if (i >= 0) list[i] = s else list.add(s)
        saveAll(c, list)
    }

    fun remove(c: Context, id: String) = saveAll(c, all(c).filter { it.id != id })

    fun create(c: Context, name: String, temp: Boolean, homeUrl: String): Session {
        val list = all(c)
        val now = System.currentTimeMillis()
        val s = Session(
            id = UUID.randomUUID().toString().replace("-", "").take(12),
            name = name,
            color = if (temp) SESSION_COLORS.last() else SESSION_COLORS[list.size % (SESSION_COLORS.size - 1)],
            temp = temp,
            homeUrl = homeUrl,
            lastUrl = "",
            created = now,
            lastUsed = now,
            desktop = false
        )
        list.add(s)
        saveAll(c, list)
        return s
    }

    fun nextDefaultName(c: Context, temp: Boolean): String {
        val list = all(c)
        var n = list.count { it.temp == temp } + 1
        val res = if (temp) R.string.default_temp_name else R.string.default_session_name
        while (list.any { it.name == c.getString(res, n) }) n++
        return c.getString(res, n)
    }
}

/** Separate WebView profiles = separate cookies, localStorage, IndexedDB, cache and service workers. */
object Profiles {
    fun supported(): Boolean = try {
        WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)
    } catch (e: Throwable) {
        false
    }

    fun profile(name: String): Profile = ProfileStore.getInstance().getOrCreateProfile(name)

    fun clear(name: String) {
        val p = profile(name)
        p.cookieManager.removeAllCookies(null)
        p.cookieManager.flush()
        p.webStorage.deleteAllData()
    }

    /** Returns false when the profile is still in use by an open WebView. */
    fun delete(name: String): Boolean = try {
        val store = ProfileStore.getInstance()
        if (store.getProfile(name) == null) true else store.deleteProfile(name)
    } catch (e: Exception) {
        false
    }

    /** Sessions whose browser window is currently open. */
    val openSessions = mutableSetOf<String>()
}

/** Optional PIN lock for the whole app. */
object Lock {
    private const val PREFS = "multibox_lock"
    private const val TIMEOUT_MS = 5 * 60 * 1000L
    private var lastActive = 0L
    var locked = true
        private set

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun enabled(c: Context) = prefs(c).getString("hash", null) != null

    fun needsUnlock(c: Context): Boolean {
        if (!enabled(c)) return false
        if (!locked && System.currentTimeMillis() - lastActive > TIMEOUT_MS) locked = true
        return locked
    }

    fun touch() {
        if (!locked) lastActive = System.currentTimeMillis()
    }

    fun unlockWith(c: Context, pin: String): Boolean {
        val p = prefs(c)
        val ok = sha256(p.getString("salt", "") + ":" + pin) == p.getString("hash", null)
        if (ok) {
            locked = false
            lastActive = System.currentTimeMillis()
        }
        return ok
    }

    fun setPin(c: Context, pin: String) {
        val salt = UUID.randomUUID().toString()
        prefs(c).edit().putString("salt", salt).putString("hash", sha256("$salt:$pin")).apply()
        locked = false
        lastActive = System.currentTimeMillis()
    }

    fun removePin(c: Context) = prefs(c).edit().clear().apply()

    private fun sha256(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
}

/** Base for app screens: edge-to-edge insets and the PIN lock check. */
open class BaseActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
    }

    protected fun applyInsets(root: View) {
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsetsCompat.CONSUMED
        }
    }

    override fun onResume() {
        super.onResume()
        if (Lock.needsUnlock(this)) startActivity(android.content.Intent(this, LockActivity::class.java))
        else Lock.touch()
    }

    override fun onPause() {
        super.onPause()
        Lock.touch()
    }
}

/* ---------------- helpers ---------------- */

fun initials(name: String): String {
    val words = name.trim().split(Regex("\\s+")).filter { it.isNotEmpty() && it[0].isLetterOrDigit() }
    if (words.isEmpty()) return name.trim().take(2).uppercase().ifEmpty { "?" }
    val num = Regex("\\d+$").find(name)?.value
    if (num != null && words.size > 1) return (words[0].take(1) + num).take(3).uppercase()
    return (if (words.size > 1) words[0].take(1) + words[1].take(1) else words[0].take(2)).uppercase()
}

fun hostOf(url: String): String = try {
    Uri.parse(url).host?.removePrefix("www.") ?: ""
} catch (e: Exception) {
    ""
}

/** Turns what the user typed into a URL: an address gets https://, anything else becomes a search. */
fun normalizeUrl(input: String): String {
    val t = input.trim()
    if (t.isEmpty()) return ""
    if (Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:.*").matches(t) && !Regex("^[^/]+:\\d+.*").matches(t)) return t
    if (!t.contains(' ') && (t.contains('.') || t.startsWith("localhost"))) return "https://$t"
    return "https://www.google.com/search?q=" + Uri.encode(t)
}

fun circleDrawable(color: Int): GradientDrawable = GradientDrawable().apply {
    shape = GradientDrawable.OVAL
    setColor(color)
}

fun roundedDrawable(color: Int, radiusPx: Float): GradientDrawable = GradientDrawable().apply {
    cornerRadius = radiusPx
    setColor(color)
}

/** Colored circle with the session's initials, used for home-screen shortcuts. */
fun avatarBitmap(s: Session, sizePx: Int = 192): Bitmap {
    val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = s.color
    c.drawCircle(sizePx / 2f, sizePx / 2f, sizePx / 2f, p)
    p.color = 0xFFFFFFFF.toInt()
    p.textSize = sizePx * 0.36f
    p.typeface = Typeface.DEFAULT_BOLD
    p.textAlign = Paint.Align.CENTER
    val text = initials(s.name)
    val y = sizePx / 2f - (p.descent() + p.ascent()) / 2f
    c.drawText(text, sizePx / 2f, y, p)
    return bmp
}
