package com.multiboxsessions.app

import android.app.ActivityManager
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.widget.PopupMenu
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.Profile
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator

class BrowserActivity : BaseActivity() {

    private lateinit var session: Session
    private lateinit var webView: WebView
    private var profile: Profile? = null
    private var baseUserAgent = ""
    private var ready = false

    private lateinit var urlBar: EditText
    private lateinit var progress: LinearProgressIndicator
    private lateinit var backBtn: ImageButton
    private lateinit var forwardBtn: ImageButton

    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    private val filePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val cb = fileCallback
        fileCallback = null
        if (cb == null) return@registerForActivityResult
        val data = result.data
        val clip = data?.clipData
        val uris: Array<Uri>? = when {
            result.resultCode != RESULT_OK -> null
            clip != null && clip.itemCount > 0 -> Array(clip.itemCount) { clip.getItemAt(it).uri }
            else -> WebChromeClient.FileChooserParams.parseResult(result.resultCode, data)
        }
        cb.onReceiveValue(uris)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra(EXTRA_ID)
        val s = id?.let { SessionStore.get(this, it) }
        if (s == null || !Profiles.supported()) {
            Toast.makeText(this, R.string.session_missing, Toast.LENGTH_LONG).show()
            finish()
            return
        }
        session = s
        setContentView(R.layout.activity_browser)
        applyInsets(findViewById(R.id.root))

        urlBar = findViewById(R.id.urlBar)
        progress = findViewById(R.id.progress)
        backBtn = findViewById(R.id.backBtn)
        forwardBtn = findViewById(R.id.forwardBtn)

        // The WebView must be bound to the session's profile before anything else touches it.
        ProfileStore.getInstance().getOrCreateProfile(session.profileName)
        webView = WebView(this)
        WebViewCompat.setProfile(webView, session.profileName)
        profile = WebViewCompat.getProfile(webView)
        findViewById<FrameLayout>(R.id.webContainer).addView(
            webView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        configureWebView()
        setupChrome()
        Profiles.openSessions.add(session.id)
        ready = true

        session.lastUsed = System.currentTimeMillis()
        SessionStore.upsert(this, session)

        val requested = intent.getStringExtra(EXTRA_URL)?.let { normalizeUrl(it) }
        val restored = savedInstanceState != null && webView.restoreState(savedInstanceState) != null
        if (!restored) webView.loadUrl(requested ?: startUrl())
    }

    private fun startUrl(): String =
        session.lastUrl.ifEmpty { session.homeUrl }.ifEmpty { "https://www.google.com" }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (!ready) return
        intent.getStringExtra(EXTRA_URL)?.let { webView.loadUrl(normalizeUrl(it)) }
    }

    /* ---------------- WebView ---------------- */

    private fun configureWebView() {
        val st = webView.settings
        st.javaScriptEnabled = true
        st.domStorageEnabled = true
        st.loadWithOverviewMode = true
        st.useWideViewPort = true
        st.builtInZoomControls = true
        st.displayZoomControls = false
        st.mediaPlaybackRequiresUserGesture = false
        st.javaScriptCanOpenWindowsAutomatically = true
        // target="_blank" links and window.open() load in this same session window.
        st.setSupportMultipleWindows(false)
        st.allowFileAccess = false
        // Look like a normal mobile Chrome (some sites refuse the WebView marker).
        baseUserAgent = st.userAgentString.replace("; wv", "")
        applyUserAgent()

        profile?.cookieManager?.let { cm ->
            cm.setAcceptCookie(true)
            cm.setAcceptThirdPartyCookies(webView, true)
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                return when (uri.scheme?.lowercase()) {
                    "http", "https", "about", "data", "blob", "javascript", null -> false
                    else -> { openExternal(uri.toString()); true }
                }
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (url != null) showUrl(url)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                profile?.cookieManager?.flush()
                if (url != null && url.startsWith("http")) {
                    session.lastUrl = url
                    SessionStore.get(this@BrowserActivity, session.id)?.let { stored ->
                        stored.lastUrl = url
                        stored.lastUsed = System.currentTimeMillis()
                        SessionStore.upsert(this@BrowserActivity, stored)
                    }
                }
                updateNav()
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                if (url != null) showUrl(url)
                updateNav()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                progress.setProgressCompat(newProgress, true)
            }

            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                if (callback == null || params == null) return false
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    val i = params.createIntent()
                    if (params.mode == FileChooserParams.MODE_OPEN_MULTIPLE) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    filePicker.launch(i)
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (view == null) return
                if (customView != null) { callback?.onCustomViewHidden(); return }
                customView = view
                customViewCallback = callback
                val fs = findViewById<FrameLayout>(R.id.fullscreen)
                fs.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                fs.visibility = View.VISIBLE
                val c = WindowCompat.getInsetsController(window, window.decorView)
                c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                c.hide(WindowInsetsCompat.Type.systemBars())
            }

            override fun onHideCustomView() {
                hideCustomView()
            }
        }

        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            download(url, userAgent, contentDisposition, mimeType)
        }
    }

    private fun hideCustomView() {
        val v = customView ?: return
        val fs = findViewById<FrameLayout>(R.id.fullscreen)
        fs.removeView(v)
        fs.visibility = View.GONE
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        WindowCompat.getInsetsController(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
    }

    private fun applyUserAgent() {
        webView.settings.userAgentString = if (session.desktop) {
            val chrome = Regex("Chrome/[\\d.]+").find(baseUserAgent)?.value ?: "Chrome/130.0.0.0"
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) $chrome Safari/537.36"
        } else {
            baseUserAgent
        }
        webView.settings.useWideViewPort = true
        webView.settings.loadWithOverviewMode = true
    }

    private fun download(url: String, userAgent: String, contentDisposition: String?, mimeType: String?) {
        try {
            val name = URLUtil.guessFileName(url, contentDisposition, mimeType)
            val req = DownloadManager.Request(Uri.parse(url))
                .setMimeType(mimeType)
                .addRequestHeader("User-Agent", userAgent)
                .setTitle(name)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            // The download uses this session's own login.
            profile?.cookieManager?.getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
            if (Build.VERSION.SDK_INT >= 29) req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            else req.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, name)
            (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            Toast.makeText(this, getString(R.string.downloading, name), Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, R.string.download_failed, Toast.LENGTH_SHORT).show()
        }
    }

    private fun openExternal(url: String) {
        try {
            val i = if (url.startsWith("intent:")) Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
            else Intent(Intent.ACTION_VIEW, Uri.parse(url))
            i.addCategory(Intent.CATEGORY_BROWSABLE)
            i.component = null
            i.selector = null
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            val fallback = try {
                Intent.parseUri(url, Intent.URI_INTENT_SCHEME).getStringExtra("browser_fallback_url")
            } catch (x: Exception) {
                null
            }
            if (fallback != null && fallback.startsWith("http")) webView.loadUrl(fallback)
            else Toast.makeText(this, R.string.no_app, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, R.string.no_app, Toast.LENGTH_SHORT).show()
        }
    }

    /* ---------------- toolbar & buttons ---------------- */

    private fun setupChrome() {
        val chip = findViewById<TextView>(R.id.sessionChip)
        chip.text = session.name
        chip.background = roundedDrawable(session.color, 16 * resources.displayMetrics.density)
        chip.setOnClickListener { openSessionsList() }
        urlBar.background = roundedDrawable(getColor(R.color.surface_variant), 20 * resources.displayMetrics.density)
        updateTaskDescription()

        urlBar.setOnEditorActionListener { _, actionId, event ->
            val enter = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE || enter) {
                val target = normalizeUrl(urlBar.text.toString())
                if (target.isNotEmpty()) webView.loadUrl(target)
                urlBar.clearFocus()
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(urlBar.windowToken, 0)
                webView.requestFocus()
                true
            } else false
        }

        backBtn.setOnClickListener { if (webView.canGoBack()) webView.goBack() }
        forwardBtn.setOnClickListener { if (webView.canGoForward()) webView.goForward() }
        findViewById<View>(R.id.reloadBtn).setOnClickListener { webView.reload() }
        findViewById<View>(R.id.homeBtn).setOnClickListener {
            webView.loadUrl(session.homeUrl.ifEmpty { "https://www.google.com" })
        }
        findViewById<View>(R.id.sessionsBtn).setOnClickListener { openSessionsList() }
        findViewById<View>(R.id.menuBtn).setOnClickListener { showMenu(it) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> hideCustomView()
                    urlBar.hasFocus() -> { urlBar.clearFocus(); webView.requestFocus() }
                    webView.canGoBack() -> webView.goBack()
                    else -> finish()
                }
            }
        })
    }

    private fun showUrl(url: String) {
        if (!urlBar.hasFocus()) urlBar.setText(url)
    }

    private fun updateNav() {
        backBtn.isEnabled = webView.canGoBack()
        backBtn.alpha = if (backBtn.isEnabled) 1f else 0.35f
        forwardBtn.isEnabled = webView.canGoForward()
        forwardBtn.alpha = if (forwardBtn.isEnabled) 1f else 0.35f
    }

    private fun updateTaskDescription() {
        val td = if (Build.VERSION.SDK_INT >= 33) {
            ActivityManager.TaskDescription.Builder().setLabel(session.name).setPrimaryColor(session.color).build()
        } else {
            @Suppress("DEPRECATION")
            ActivityManager.TaskDescription(session.name, null, session.color)
        }
        setTaskDescription(td)
    }

    private fun openSessionsList() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
    }

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        val desktop = pm.menu.add(0, 1, 0, R.string.desktop_site)
        desktop.isCheckable = true
        desktop.isChecked = session.desktop
        pm.menu.add(0, 2, 1, R.string.share_page)
        pm.menu.add(0, 3, 2, R.string.copy_link)
        pm.menu.add(0, 4, 3, R.string.open_in_other)
        pm.menu.add(0, 5, 4, R.string.all_sessions)
        pm.setOnMenuItemClickListener { item ->
            val url = webView.url ?: ""
            when (item.itemId) {
                1 -> {
                    session.desktop = !session.desktop
                    SessionStore.get(this, session.id)?.let { it.desktop = session.desktop; SessionStore.upsert(this, it) }
                    applyUserAgent()
                    webView.reload()
                }
                2 -> if (url.isNotEmpty()) {
                    val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, url)
                    startActivity(Intent.createChooser(send, null))
                }
                3 -> if (url.isNotEmpty()) {
                    (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("url", url))
                    Toast.makeText(this, R.string.link_copied, Toast.LENGTH_SHORT).show()
                }
                4 -> openInOtherSession(url)
                5 -> openSessionsList()
            }
            true
        }
        pm.show()
    }

    private fun openInOtherSession(url: String) {
        val others = SessionStore.all(this).filter { it.id != session.id }
        if (others.isEmpty() || url.isEmpty()) return
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.open_in_other)
            .setItems(others.map { it.name }.toTypedArray<CharSequence>()) { _, which ->
                startActivity(newIntent(this, others[which].id, url))
            }
            .show()
    }

    /* ---------------- lifecycle ---------------- */

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (ready) webView.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        if (ready) webView.onResume()
    }

    override fun onPause() {
        if (ready) {
            webView.onPause()
            profile?.cookieManager?.flush()
        }
        super.onPause()
    }

    override fun onDestroy() {
        if (ready) {
            Profiles.openSessions.remove(session.id)
            fileCallback?.onReceiveValue(null)
            fileCallback = null
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.stopLoading()
            webView.destroy()
            // Temporary sessions are wiped as soon as their window is closed.
            if (session.temp && isFinishing) {
                val app = applicationContext
                val name = session.profileName
                val id = session.id
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    if (Profiles.delete(name)) SessionStore.remove(app, id)
                }, 300)
            }
        }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_ID = "session_id"
        const val EXTRA_URL = "url"

        fun newIntent(ctx: Context, sessionId: String, url: String? = null): Intent =
            Intent(ctx, BrowserActivity::class.java)
                .setData(Uri.parse("multibox://session/$sessionId"))
                .putExtra(EXTRA_ID, sessionId)
                .apply { if (url != null) putExtra(EXTRA_URL, url) }
                .addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT)
    }
}
