package com.multiboxsessions.app

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : BaseActivity() {

    private lateinit var adapter: SessionAdapter
    private var pendingUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        applyInsets(findViewById(R.id.root))

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_pin -> { pinSettings(); true }
                R.id.action_about -> { about(); true }
                else -> false
            }
        }

        adapter = SessionAdapter(onOpen = { open(it) }, onMore = { s, v -> sessionMenu(s, v) })
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        findViewById<View>(R.id.fab).setOnClickListener { newSessionDialog() }
        findViewById<View>(R.id.updateWebViewBtn).setOnClickListener {
            openPlayStore("com.google.android.webview")
        }
        handleShare(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    override fun onResume() {
        super.onResume()
        cleanupTemporarySessions()
        refresh()
    }

    private fun refresh() {
        val supported = Profiles.supported()
        findViewById<View>(R.id.unsupportedCard).visibility = if (supported) View.GONE else View.VISIBLE
        findViewById<View>(R.id.fab).isEnabled = supported
        val sessions = SessionStore.all(this).sortedByDescending { it.lastUsed }
        adapter.submit(sessions)
        findViewById<View>(R.id.emptyView).visibility = if (sessions.isEmpty() && supported) View.VISIBLE else View.GONE
        val banner = findViewById<TextView>(R.id.pendingBanner)
        val url = pendingUrl
        if (url != null) {
            banner.text = getString(R.string.open_with_session) + "\n" + url
            banner.visibility = View.VISIBLE
        } else {
            banner.visibility = View.GONE
        }
    }

    /** A link shared from another app: the next session tapped opens it. */
    private fun handleShare(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return
        val url = Regex("https?://\\S+").find(text)?.value ?: text.trim()
        if (url.isNotEmpty()) pendingUrl = url
        refresh()
    }

    /** Temporary sessions whose window is closed are deleted with all their data. */
    private fun cleanupTemporarySessions() {
        if (!Profiles.supported()) return
        for (s in SessionStore.all(this)) {
            if (s.temp && s.id !in Profiles.openSessions) {
                if (Profiles.delete(s.profileName)) SessionStore.remove(this, s.id)
            }
        }
    }

    private fun open(s: Session) {
        if (!Profiles.supported()) return
        val url = pendingUrl
        pendingUrl = null
        startActivity(BrowserActivity.newIntent(this, s.id, url))
    }

    /* ---------------- dialogs ---------------- */

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun newSessionDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
        }
        val name = EditText(this).apply {
            hint = getString(R.string.session_name)
            setText(SessionStore.nextDefaultName(this@MainActivity, false))
            filters = arrayOf(InputFilter.LengthFilter(40))
            setSingleLine()
            selectAll()
        }
        val url = EditText(this).apply {
            hint = getString(R.string.start_page_hint)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
            pendingUrl?.let { setText(it) }
        }
        val urlLabel = TextView(this).apply {
            text = getString(R.string.start_page)
            setPadding(0, dp(12), 0, 0)
        }
        val temp = CheckBox(this).apply { text = getString(R.string.temporary) }
        temp.setOnCheckedChangeListener { _, checked ->
            name.setText(SessionStore.nextDefaultName(this@MainActivity, checked))
        }
        box.addView(name)
        box.addView(urlLabel)
        box.addView(url)
        box.addView(temp)

        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.new_session)
            .setView(box)
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.create) { _, _ ->
                val n = name.text.toString().trim().ifEmpty { SessionStore.nextDefaultName(this, temp.isChecked) }
                val home = normalizeUrl(url.text.toString())
                val s = SessionStore.create(this, n, temp.isChecked, home)
                open(s)
            }
            .show()
    }

    private fun sessionMenu(s: Session, anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, R.string.rename)
        pm.menu.add(0, 2, 1, R.string.change_color)
        pm.menu.add(0, 3, 2, R.string.set_start_page)
        pm.menu.add(0, 4, 3, R.string.add_shortcut)
        pm.menu.add(0, 5, 4, R.string.log_out)
        pm.menu.add(0, 6, 5, R.string.delete_session)
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> textDialog(getString(R.string.rename), s.name, 40) { v ->
                    if (v.isNotBlank()) { s.name = v.trim(); SessionStore.upsert(this, s); refresh() }
                }
                2 -> colorDialog(s)
                3 -> textDialog(getString(R.string.set_start_page), s.homeUrl, 500) { v ->
                    s.homeUrl = normalizeUrl(v); SessionStore.upsert(this, s); refresh()
                }
                4 -> addShortcut(s)
                5 -> confirm(getString(R.string.confirm_clear, s.name), getString(R.string.log_out)) {
                    Profiles.clear(s.profileName)
                    s.lastUrl = ""
                    SessionStore.upsert(this, s)
                    Toast.makeText(this, R.string.cleared, Toast.LENGTH_SHORT).show()
                    refresh()
                }
                6 -> confirm(getString(R.string.confirm_delete, s.name), getString(R.string.delete)) {
                    deleteSession(s)
                }
            }
            true
        }
        pm.show()
    }

    private fun deleteSession(s: Session) {
        if (s.id in Profiles.openSessions || !Profiles.delete(s.profileName)) {
            Toast.makeText(this, R.string.close_session_first, Toast.LENGTH_LONG).show()
            return
        }
        SessionStore.remove(this, s.id)
        try {
            ShortcutManagerCompat.disableShortcuts(this, listOf("session_${s.id}"), null)
        } catch (e: Exception) {
            // no shortcut for this session
        }
        refresh()
    }

    private fun colorDialog(s: Session) {
        val names = arrayOf("Blue", "Red", "Green", "Purple", "Orange", "Cyan", "Pink", "Yellow", "Grey")
        val items = names.mapIndexed { i, n ->
            SpannableString("●   $n").apply {
                setSpan(ForegroundColorSpan(SESSION_COLORS[i]), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }.toTypedArray<CharSequence>()
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.change_color)
            .setItems(items) { _, which ->
                s.color = SESSION_COLORS[which]
                SessionStore.upsert(this, s)
                refresh()
            }
            .show()
    }

    private fun addShortcut(s: Session) {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(this)) {
            Toast.makeText(this, R.string.shortcut_not_supported, Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(ShortcutActivity.ACTION)
            .setClass(this, ShortcutActivity::class.java)
            .putExtra(BrowserActivity.EXTRA_ID, s.id)
        val info = ShortcutInfoCompat.Builder(this, "session_${s.id}")
            .setShortLabel(s.name)
            .setIcon(IconCompat.createWithBitmap(avatarBitmap(s)))
            .setIntent(intent)
            .build()
        ShortcutManagerCompat.requestPinShortcut(this, info, null)
    }

    private fun textDialog(title: String, value: String, max: Int, onSave: (String) -> Unit) {
        val input = EditText(this).apply {
            setText(value)
            filters = arrayOf(InputFilter.LengthFilter(max))
            setSingleLine()
            selectAll()
        }
        val box = LinearLayout(this).apply {
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setView(box)
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.save) { _, _ -> onSave(input.text.toString()) }
            .show()
    }

    private fun confirm(message: String, ok: String, action: () -> Unit) {
        MaterialAlertDialogBuilder(this)
            .setMessage(message)
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(ok) { _, _ -> action() }
            .show()
    }

    /* ---------------- PIN lock & about ---------------- */

    private fun pinSettings() {
        if (!Lock.enabled(this)) {
            askNewPin()
            return
        }
        val options = arrayOf<CharSequence>(getString(R.string.change_pin), getString(R.string.remove_pin))
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.pin_lock)
            .setItems(options) { _, which ->
                askCurrentPin {
                    if (which == 0) askNewPin() else {
                        Lock.removePin(this)
                        Toast.makeText(this, R.string.pin_removed, Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }

    private fun pinField(hintRes: Int) = EditText(this).apply {
        hint = getString(hintRes)
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        filters = arrayOf(InputFilter.LengthFilter(8))
    }

    private fun askCurrentPin(onOk: () -> Unit) {
        val f = pinField(R.string.enter_pin)
        val box = LinearLayout(this).apply { setPadding(dp(24), dp(8), dp(24), 0); addView(f) }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.enter_pin)
            .setView(box)
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.unlock) { _, _ ->
                if (Lock.unlockWith(this, f.text.toString())) onOk()
                else Toast.makeText(this, R.string.wrong_pin, Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun askNewPin() {
        val a = pinField(R.string.new_pin)
        val b = pinField(R.string.repeat_pin)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(a)
            addView(b)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.set_pin)
            .setView(box)
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.save) { _, _ ->
                val p = a.text.toString()
                when {
                    !Regex("^\\d{4,8}$").matches(p) -> Toast.makeText(this, R.string.pin_format, Toast.LENGTH_LONG).show()
                    p != b.text.toString() -> Toast.makeText(this, R.string.pin_mismatch, Toast.LENGTH_LONG).show()
                    else -> {
                        Lock.setPin(this, p)
                        Toast.makeText(this, R.string.pin_saved, Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }

    private fun about() {
        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
        val b = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.app_name)
            .setMessage(getString(R.string.about_text, version) + "\n\n" + getString(R.string.google_signin_note))
            .setPositiveButton(android.R.string.ok, null)
        if (PRIVACY_URL.isNotEmpty()) {
            b.setNeutralButton(R.string.privacy_policy) { _, _ ->
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(PRIVACY_URL))) } catch (e: Exception) { }
            }
        }
        b.show()
    }

    private fun openPlayStore(pkg: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")))
        } catch (e: ActivityNotFoundException) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg")))
        }
    }

    companion object {
        /** Put your privacy policy page here (the same one used for the Chrome extension). */
        const val PRIVACY_URL = ""
    }
}

class SessionAdapter(
    private val onOpen: (Session) -> Unit,
    private val onMore: (Session, View) -> Unit
) : RecyclerView.Adapter<SessionAdapter.Holder>() {

    private var items: List<Session> = emptyList()

    fun submit(list: List<Session>) {
        items = list
        @Suppress("NotifyDataSetChanged")
        notifyDataSetChanged()
    }

    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val avatar: TextView = v.findViewById(R.id.avatar)
        val name: TextView = v.findViewById(R.id.name)
        val subtitle: TextView = v.findViewById(R.id.subtitle)
        val more: ImageButton = v.findViewById(R.id.more)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_session, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: Holder, position: Int) {
        val s = items[position]
        val ctx = h.itemView.context
        h.avatar.text = initials(s.name)
        h.avatar.background = circleDrawable(s.color)
        h.name.text = s.name
        val host = hostOf(s.lastUrl.ifEmpty { s.homeUrl })
        val parts = mutableListOf<String>()
        if (s.temp) parts.add(ctx.getString(R.string.temp_tag))
        parts.add(host.ifEmpty { ctx.getString(R.string.no_logins) })
        h.subtitle.text = parts.joinToString(" · ")
        h.itemView.setOnClickListener { onOpen(s) }
        h.more.setOnClickListener { onMore(s, it) }
    }
}
